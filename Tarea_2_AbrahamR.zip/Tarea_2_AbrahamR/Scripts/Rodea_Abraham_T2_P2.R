                                           ### Eigenvalores ### 

#Para realizar los codigos se consultaron distintas paginas webs y foros. No se usaron recursos de inteligencia artificial en estos codigos

# Genera un programa que te de 4 numeros reales al azar y con ello genera una matriz de 2 ×2 y a partir de ella: Puntaje 30

#(a) Calcula la traza de la matriz

#(b) Calcula la determinante de la matriz

#(c) Calcula, sin utilizar librerıas especializadas, los eigenvalores de la matriz

#(d) Si la matriz viene de un problema de puntos de equilibrio en 2 dimensiones, determina a partir de la traza y determinante, el tipo y clase de estabilidad que tiene.

#(e) Si la matriz viene de un problema de puntos de equilibrio en 2 dimensiones, determina a partir de la parte real de los eigenvalores, el tipo y clase de estabilidad que tienen.

#(f) Como podrıas genera 100 matrices al azar y demostrar que aproximadamente el 50% de las veces es un punto silla.

## Generamos 4 números al azar ## 

numeros<-sample(0:1000,4) # Use la función "sample" para generar 4 números aleatorios entre 0-1,000, esto se asigno al objeto "numeros" 
numeros # Imprimimos el objeto "numeros" para conocer lo 4 números generados al azar por la linea anterior

### Generamos la matriz ### 

matriz<-matrix(numeros,2,2) # Use la funcion "matrix" para generar una matriz. coloque el objeto "numeros" para que los valores de la matriz fuesen tomados de los contenidos en dicho objeto, ademas, especifique que la matriz sea de 2 columnas y 2 filas 

matriz # Imprimimos la matriz resultante 

## (a) Calculamos la traza de la matriz ##

traza<- matriz[1,1] + matriz[2,2] # Para calcular la traza de la matriz sume los elemetos de la diagonal, en el caso de una matriz 2x2 dichos elementos tienen una posición [1,1] y [2,2], el resultado se asigno al objeto "traza"

if(traza<0|traza>0|traza==0){ # En este caso use "if" acompañado del operador logico "or" para que el mensaje se imprima si el valor de la traza se encuentra dentro de cualquiera de los tres parametros estrablecidos

print("La traza de una matriz se calcula sumando los elementos de su diagonal") # Decidi imprimir este mensaje para recordar al usuario como se calcula la traza de una matriz 

print(paste("La traza de tu matriz es de: ",traza)) # Imprimimos el valor de la traza acompañado de una leyenda que especifica a que corresponde dicho valor 
}

## (b) Calculamos la determinante de una matriz ## 

## Podemos usar la funcion "det" la cual esta en R base y calcula el valor de la determinate de una matriz ##

determinate1<-det(matriz) # Usamos la función "det" para calcula la determinante
determinate1 # Imprimir la determinate 


determinante2<- (matriz[1,1] * matriz[2,2])-(matriz[1,2] * matriz[2,1]) # Tambien podemos calcular la determinante sin necesidad de usar una funcion, la determinate se calcula restando el producto de los elementos de la sengunda diagonal al producto de los elementos de la diagonal de la matriz 
determinante2 #Imprimimos el resultado de la determinante calculado de forma alternativa 

# Independientemente del metodo usado el resultado siempre será el mismo 

## (c) calcular eigen valores ##

#Para calcular los eigen valores de una matriz podemos usar la función "eigen" disponible en R base o calcularlos mediante una formula 

## Metodo con funcion "eigen" ##

eigenvalores<-eigen(matriz) # Al usar esta funcion nos arrojara tanto eigenvalores como eigenvectores 

eigenvalores<- eigenvalores$values # Debido a que solo deseamos imprimir los eigenvalores usamos "$values" para omitir los eigenvectores

eigenvalores # Imprimir los eigen valores de la matriz 

eigenvalor1a<-eigenvalores[1] # Asignamos cada uno de los eigen valores a un nuevo elemento, esto nos permite separarlos. Esto sera necesario para la parte (e) del ejercicio

eigenvalor1a

eigenvalor2a<-eigenvalores[2] # Usamos "[x]" para establecer que queremos asignar el elemento con posición x del objeto "eigenvalores" al nuevo objeto "eigenvalores1/2"

eigenvalor2a

## Metodo con formula ##

# Este metodo usa una estructura similar a la formula general para ecuaciones cuadraticas, donde a=1, b=traza, c=determinante

a<-1 #Asignamos el valor 1 al objeto "a"

eigenvalor1<-(traza + sqrt(traza^2 - 4*1*determinate1))/2*a #Calculamos el primer eigenvalor

eigenvalor1

eigenvalor2<-(traza - sqrt(traza^2 - 4*1*determinate1))/2*a #Calculamos el segundo eigenvalor

eigenvalor2

#### Cualquiera de los dos metodos puede usarse para obtener los siguientes resultados, pues son iguales
####En este caso usaré los eigenvalores obtenidos ´por formula general

# Imprimir los eigenvectores de la matriz # 

eigenvectores<-eigen(matriz)# Al usar esta funcion nos arrojara tanto eigenvalores como eigenvectores 

eigenvectores<-eigenvectores$vectors # Usamos "$vectors" para imprimir unicamente los eigenvectores

eigenvectores # Imprimimos eigenvectores 

## (d)Tipo y clase de estabilidad en funcion de la traza y la determinante ##

delta<- traza^2 - 4*determinate1 # Calculamos la delta, pues, podría ser necesaria para determinar la estabilidad
delta # Debido a que los objetos "traza" y "determinante" ya poseen un valor calculado a partir de nuestra matriz no es necesario especificar la matriz de la que vienen la traza y la determinate

if(determinate1<0){ # Usamos "if", pues, para determinar el tipo de estabilidad se deben cumplir condiciones especificas. En este caso use "determinante1" pero el resultado sería el mismo usando "determinante2" 

  print ("El resultado de tu problema te lleva a un equilibrio de tipo punto silla") # Imprimimos al usuario un mensaje que le informa la naturaleza de la estabilidad

  print(paste("El valor de tu determinate es de: ",determinante1)) # Imprimimos la determinante para recordarle al usuario el valor de la misma 

  print("Si deseas observar un esquema de los tipos de estabilidad así como los criteriospara determinar cada uno de ellos puedes ir al archivo -Esquema-estabilidades.pdf- disponible en la carpeta -Bases_de_datos-")
  
} else if(traza<0 & determinate1>0 & delta>0){# Usamos "else if" debido a que esta linea debe ejecutarse si no se cumple la condición de la linea previa. Es indispensable usar el operador "&" ya que se necesita que la traza sea menor que 0 y que la determinate sea mayor a 0. Si no usamos "&" se podría ejecutar esta linea cuando la traza es menor que 0 y la determinate tambien es menor que 0, esto seria un error. El valor de "delta" tambien se agrego con el operador "&" debido a que es una condición necesaria para determinar el tipo de estabilidad 

  print("El punto de equilibrio es estable, de tipo atractor") # Imprimios los valores de traza, determimante y delta para que el usuario pueda visualizarlos y confirmar que cumplen con los criterios del tipo y clase de estabilidad que le fue arrojada
  
  print(paste("El valor de la determinante es: ", determinate1))
  
  print(paste("El valor de la traza es: ",traza))
  
  print(paste("El valor de delta es: ", delta))
  
  print("Si deseas observar un esquema de los tipos de estabilidad así como los criteriospara determinar cada uno de ellos puedes ir al archivo -Esquema-estabilidades.pdf- disponible en la carpeta -Bases_de_datos-") # Proporcionamos al usuario la posibilidad de observar el esquema a partir del cual se determina el tipo y clase de la estabilidad. Perdon por robarte la imagen del esquema :(

}else if(traza<0 & determinate1>0 & delta<0){ # Encada linea de "else if" establecemos los criterios para cada tipo y clase de estabilidad

  print("El punto de equilibrio es estable, de tipo atractor espiral")
  
  print(paste("El valor de la determinante es: ", determinate1))
  
  print(paste("El valor de la traza es: ",traza))
  
  print(paste("El valor de delta es: ", delta))
  
  print("Si deseas observar un esquema de los tipos de estabilidad así como los criteriospara determinar cada uno de ellos puedes ir al archivo -Esquema-estabilidades.pdf- disponible en la carpeta -Bases_de_datos-")

}else if(traza>0 & determinate1>0 & delta>0){ # Encada linea de "else if" establecemos los criterios para cada tipo y clase de estabilidad

  print("El punto de equilibrio es inestable, de tipo repulsor")
  
  print(paste("El valor de la determinante es: ", determinate1))
  
  print(paste("El valor de la traza es: ",traza))
  
  print(paste("El valor de delta es: ", delta))
  
  print("Si deseas observar un esquema de los tipos de estabilidad así como los criteriospara determinar cada uno de ellos puedes ir al archivo -Esquema-estabilidades.pdf- disponible en la carpeta -Bases_de_datos-")

}else if(traza>0 & determinate1>0 & delta<0){ # Encada linea de "else if" establecemos los criterios para cada tipo y clase de estabilidad

print("El punto de equilibrio es inestable, de tipo repulsor espiral")
  
  print(paste("El valor de la determinante es: ", determinate1))
  
  print(paste("El valor de la traza es: ",traza))
  
  print(paste("El valor de delta es: ", delta))
  
  print("Si deseas observar un esquema de los tipos de estabilidad así como los criteriospara determinar cada uno de ellos puedes ir al archivo -Esquema-estabilidades.pdf- disponible en la carpeta -Bases_de_datos-")

}


### (e) Tipo y clase de estabilidad en funcion de los eigen valores ### 

if(eigenvalor1>0 | eigenvalor2>0){ # Use el condicional "|" para establecer que al menos una de las condiciones debe cumplirse para imprimir estas lineas
  
  print("El punto de quilibrio es inestable") # Imprimimos el tipo de estabilidad
  
  print("Si al menos uno de los eigenvalores es positivo entonces el punto de equilibrio es inestable")
  
  print(paste("El valor de el eigenvalor 1 es: ", eigenvalor1)) # Colocamos los eigenvalores para que sean visualizados por el usuario
  
  print(paste("El valor de el eigenvalor 2 es: ", eigenvalor2))
  
} else if (eigenvalor1<0 & eigenvalor2<0){ # Use el operador "&" ya que ambas condiciones deben cumplirse para tener este tipo de estabilidad
  
  print("El punto de equilibrio es estable")
  
  print("Si ambos eigenvalores son negtivos entonces el punto de equilibrio es estable")
  
  print(paste("El valor de el eigenvalor 1 es: ", eigenvalor1))
  
  print(paste("El valor de el eigenvalor 2 es: ", eigenvalor2))
  
  
} else if (eigenvalor1==0 | eigenvalor2==0){ # Use el operador "|" debido a que que al menos una de las condiciones debe cumplirse para imprimir estas lineas
  
  print("El punto de equilibrio es inestable")
  
  print("Si al menos uno de los eigenvalores es igual a 0 entonces el sistema será inestable")
  
  print(paste("El valor de el eigenvalor 1 es: ", eigenvalor1))
  
  print(paste("El valor de el eigenvalor 2 es: ", eigenvalor2))
  
}

## (f) Generar 100 matrices al azar y demostrar que al menos el 50% serán punto silla ##
  
  
  

