                                ### JUrassic Park ###

#Para realizar los codigos se consultaron distintas paginas webs y foros. No se usaron recursos de inteligencia artificial en estos codigos

#A partir del archivo FASTA llamado DinoJurassic.fna. Esta secuencia la puse en formato fasta y es la secuencia que aparece en en libro de Michael Crichton Jurassic Park de 1993
#(a) Lee el archivo en R y calcula el porcentaje de GC y de C seguidas de G
#(b) Blastea la secuencia determina e interpreta tu resultado. ¿cuales serıan los organismos mas cercanos? ¿Tiene sentido que la secuencia sea de dinosaurios?
#(c) Elabora una grafica de e-values y los organismos mas cercanos.
#(d) Elabora un arbol filogenetico con los 10 organismos mas cercanos

### Para correr el siguiente codigo necesitas las siguientes librerias ###

if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("rBLAST")

library(Biostrings)

library(BiocGenerics)

library(msa)

library(rBLAST)

#### Abrir secuencia #### 

secuenciaJ<- readDNAStringSet("Bases_de_datos/DinoJurassic.fna") # Usamos la funcion "readDNAStringSet" de la libreria "Biostrings" para leer las secuencias del archivo .fna. La direccion de la secuencia es "Bases_de_datos/DinoJurassic.fna", esto permite que cualquiera con este proyecto pueda abrir dicha base de datos  
secuenciaJ

###(a) Lee el archivo en R y calcula el porcentaje de GC y de C seguidas de G

# Debemos conocer el tamaño de la decuencia, para ello usamos la funcion "width" de la libreria "BiocGenerics"

tamaño<-width(secuenciaJ) # El tamaño es de 1,200 nucleotidos, bastante pequeña

tamaño

# Ahora tenemos que calcular la cantidad de veces que "GC" aparece en la secuencia 

cantidadGC<-vcountPattern("GC",secuenciaJ) # Use la funcion "vcountPatter" para contar la cantidad de veces que aparece el patron "GC" en la secuenciaJ
cantidadGC

# Con estos datos ya podemos calcular el porcentaje de "GC" en la secuencia. Para ello realizamos la siguiente formula

porcentajeGC<- cantidadGC * 100 / tamaño # Calculamos el porcentaje de GC en la secuencia

porcentajeGC<-print(paste("El porcentaje de GC en la secuencia es de: ",porcentajeGC,"%")) # Use un "print" para presentar el resultado en un formato mas agradable

## Para calcular el porcentaje de C seguidas de G tenemos que hacer algo similar al procedimiento anterior, pero esta vez con "CG"

cantidadCG<-vcountPattern("CG",secuenciaJ) # Use la funcion "vcountPatter" para contar la cantidad de veces que aparece el patron "CG" en la secuenciaJ
cantidadCG # El patron "CG" es igual que C seguidas de G

# Con estos datos ya podemos calcular el porcentaje de "CG" en la secuencia. Para ello realizamos la siguiente formula

porcentajeCG<- cantidadCG * 100 / tamaño # Calculamos el porcentaje de CG en la secuencia

porcentajeCG<-print(paste("El porcentaje de CG en la secuencia es de: ",porcentajeCG,"%")) # Use un "print" para presentar el resultado en un formato mas agradable

###(b) Blastea la secuencia determina e interpreta tu resultado ###

# Para relizar un BLAST desde R usaremos el paquete rentrez

jurassicblast<- (sequence = secuenciaJ, program = "blastn", database = "nucleotide")


# Mientras intentaba instalar un paquete para realizar el BLAST no se que ocurrio que ya no me permite abrir el archivo usando la linea "secuenciaJ<- readDNAStringSet("Bases_de_datos/DinoJurassic.fna")"

#Por lo tanto, hice lo siguiente 
#Copie la secuencia y la cree usando la funcion "DNAString"

secuenciaJ<-DNAString("GCGTTGCTGGCGTTTTTCCATAGGCTCCGCCCCCCTGACGAGCATCACAAAAATCGACGCGGTGGCGAAACCCGACAGGACTATAAAGATACCAGGCGTTTCCCCCTGGAAGCTCCCTCGTGTTCCGACCCTGCCGCTTACCGGATACCTGTCCGCCTTTCTCCCTTCGGGAAGCGTGGCTGCTCACGCTGTACCTATCTCAGTTCGGTGTAGGTCGTTCGCTCCAAGCTGGGCTGTGTGCCGTTCAGCCCGACCGCTGCGCCTTATCCGGTAACTATCGTCTTGAGTCCAACCCGGTAAAGTAGGACAGGTGCCGGCAGCGCTCTGGGTCATTTTCGGCGAGGACCGCTTTCGCTGGAGATCGGCCTGTCGCTTGCGGTATTCGGAATCTTGCACGCCCTCGCTCAAGCCTTCGTCACTCCAAACGTTTCGGCGAGAAGCAGGCCATTATCGCCGGCATGGCGGCCGACGCGCTGGGCTGGCGTTCGCGACGCGAGGCTGGATGGCCTTCCCCATTATGATTCTTCTCGCTTCCGGCGGCCCGCGTTGCAGGCCATGCTGTCCAGGCAGGTAGATGACGACCATCAGGGACAGCTTCAACGGCTCTTACCAGCCTAACTTCGATCACTGGACCGCTGATCGTCACGGCGATTTATGCCGCACATGGACGCGTTGCTGGCGTTTTTCCATAGGCTCCGCCCCCCTGACGAGCATCACAAACAAGTCAGAGGTGGCGAAACCCGACAGGACTATAAAGATACCAGGCGTTTCCCCCTGGAAGCGCTCTCCTGTTCCGACCCTGCCGCTTACCGGATACCTGTCCGCCTTTCTCCCTTCGGGCTTTCTCAATGCTCACGCTGTAGGTATCTCAGTTCGGTGTAGGTCGTTCGCTCCAAGCTGACGAACCCCCCGTTCAGCCCGACCGCTGCGCCTTATCCGGTAACTATCGTCTTGAGTCCAACACGACTTAACGGGTTGGCATGGATTGTAGGCGCCGCCCTATACCTTGTCTGCCTCCCCGCGGTGCATGGAGCCGGGCCACCTCGACCTGAATGGAAGCCGGCGGCACCTCGCTAACGGCCAAGAATTGGAGCCAATCAATTCTTGCGGAGAACTGTGAATGCGCAAACCAACCCTTGGCCATCGCGTCCGCCATCTCCAGCAGCCGCACGCGGCGCATCTCGGGCAGCGTTGGGTCCT")

secuenciaJ

### Debido a que no logre realizar el BLAST desde R, lo realice desde la pagina web del NCBI. Descargue las secuencias y las agregue en la carpeta de base de datos con el nombre de "DinoBLAST"

DinoBLAST<-readDNAStringSet("Base_de_datos/DinoBLAST.TXT")

## Las secuencias arrojadas por el NBLAST son de vectores de clonacion, en su ayoria de bacterias y algunos de levaduras
## Desconozco el contexto en el que se da la secuencia en el libro, pero por lo visto en la pelicula pienso lo siguiente
## La secuencia tiene tantas similitudes con vectores de clonancion porque de eso es la secuencia, se menciona que el ADN de dinosaurio se obtiene de un mosquito
## Desconozco la capacidad de un mosquito para almacenar ADN, pero supongo que no conserva genomas completos.
## Creo que el poco ADN recuperado del mosquito se introdujo en un vector de clonacion para incrementar la cantidad de copias del mismo
## Me hace sentido, pues, para 1993 los vectores de clonacion ya eran bastante populares. Recordando que el plasmido pBR322 fue creado en 1977 por el mexicano Francisco Bolívar Zapata
## Me resulta curioso que usaran vectores en en lugar de PCR, supongo que esto se debe a que en aque entonces esta tecnica no era tan popular como los vectores
## La secuencia es muy corta, 1,200 nucleotidos, por lo tanto la cantidad de ADN de dinosaurio en la misma debe ser infima
## En la pelicula mencionan que las secciones dañadas del ADN de dinosaurio fueron sustituidas con ADN de ranas
## Considerando la poca cantidad de ADN lo mas probable es que en lugar de dinosaurios con ADN de ranas sean ranas,o sabra dios que quimera usaron,con un poco de ADN de dinosaurio