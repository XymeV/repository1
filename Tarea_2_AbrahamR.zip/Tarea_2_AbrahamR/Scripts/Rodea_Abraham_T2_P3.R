                                      ### Calificaciones ###

#Para realizar los codigos se consultaron distintas paginas webs y foros. No se usaron recursos de inteligencia artificial en estos codigos

# Elabora un programa que, a partir de un vector de calificaciones de ex´amenes parciales (3), y de un vector de calificaciones de tareas y ex´amenes quincenales (10), determine si esa alumnx exentar´ ıa o no el curso de bioinform´atica con los criterios que establecimos al inicio del curso que puedes consultar en el programa que en el classroom. Asume que en el resto de los criterios tienen en 100%

#En el siguente codigo la calificacion máxima es 1, por lo tanto, 1 = 10 de calificación

### Coloca las calificaciones de tus examenes parciales ###

primer_parcial<- as.numeric (readline (prompt = "Calificacion de tu primer parcial: ")) #Use un "readline" para que el usuario coloque cada una de sus calificaciones correpondientes a cada parcial

segundo_parcial <- as.numeric (readline (prompt = "Calificacion de tu segundo parcial: ")) # Use "as.numeric" para guardar el valor introducido por el usuario como numerico, de lo contrario el objeto se guardaria como caracter 

tercer_parcial<- as.numeric (readline (prompt = "Calificacion de tu primer parcial: " ))

calificaciones_parciales<-c(primer_parcial,segundo_parcial,tercer_parcial) # Creamos un vector donde se agrupen las tres calificaciones 

calificaciones_parciales

### Coloca las calificaciones de tus quincenales/tareas ### 

calificacion1<- as.numeric (readline (prompt = "Calificacion de tu primer actividad: ")) # Debido a que tareas y quincenales valen 30% en conjunto el readline pide que introduzcas la calificacion de x "actividad", decidi nombraras como "actividades" para fines practicos 

calificacion2<- as.numeric (readline (prompt = "Calificacion de tu segunda actividad: "))

calificacion3<- as.numeric (readline (prompt = "Calificacion de tu tercera actividad: "))

calificacion4<- as.numeric (readline (prompt = "Calificacion de tu cuarta actividad: "))

calificacion5<- as.numeric (readline (prompt = "Calificacion de tu quinta actividad: "))

calificacion6<- as.numeric (readline (prompt = "Calificacion de tu sexta actividad: "))

calificacion7<- as.numeric (readline (prompt = "Calificacion de tu septima actividad: "))

calificacion8<- as.numeric (readline (prompt = "Calificacion de tu octava actividad: "))

calificacion9<- as.numeric (readline (prompt = "Calificacion de tu novena actividad: "))

calificacion10<- as.numeric (readline (prompt = "Calificacion de tu decima actividad: ")) # El usuario debe introducir las 10 calificaciones, incluido si esta es 0 

calificaciones_actividades<-c(calificacion1,calificacion2,calificacion3,calificacion4,calificacion5,calificacion6,calificacion7,calificacion8,calificacion9,calificacion10) # Creamos un vector que agrupa todas las calificaciones de las actividades

### Tienes extra? ###

#Si no tienes ningun porcentaje extra coloca un 0 
#Recuerda que la calificacióm maxima en este apartado es de 0.05
extra<-as.numeric (readline (prompt = "Calificacion de actividades extra: "))


porcentaje_parciales<- mean(calificaciones_parciales) * 0.5 / 10 # Calculamos el porcentaje de examenes del usuario en función del promedio de las calificaciones de sus examenes parciales

porcetaje_actividades<- mean(calificaciones_actividades) * 0.3 /10 # Calculamos el porcentaje de actividades del usuario en función del promedio de las calificaciones de sus actividades

porcentajes_restantes<- c(0.1,0.05,0.05) # Creamos un vector que contenga los porcentajes restantes, dadas las indicaciones se considera que en todos ellos el usuario tiene la calificación maxima

porcentajes_restantes<-sum(porcentajes_restantes) # Creamos un objeto que contenga la suma de los objetos del vector anterior, esto para obtener un solo valor numerico de dicho vector

tu_calificacion<- porcentaje_parciales + porcetaje_actividades + porcentajes_restantes + extra # Calculamos la calificación sumando los porcentajes de cada uno de los apartados evaluados 

tu_calificacion<- tu_calificacion*10 # Multiplicamos por 10 para que la calificación se le proporcione al usuario en un formato mas familiar


if(tu_calificacion<7.0){ # Especificamos las condiciones que se deben cumplir para exentar o ir a final
  
  print("Estas en final")
  
  print(paste("Tu calificacion es de: ", tu_calificacion))
  
  print("Recuerda revisar los criterios de evaluación disponibles en el programa de la materia")
  
} else if (tu_calificacion>=0.7){
  
  print("Felices vacaciones, estas exento")
  
  print(paste("Tu calificacion es de: ", tu_calificacion))
  
  print("Recuerda revisar los criterios de evaluación disponibles en el programa de la materia")
  
}


### Te fuiste a final? ### 

calificacion_final<- as.numeric(readline (prompt = "Calificacion de tu examen final: "))

if(calificacion_final>= 6.0){
  
  print("Feliz navidad")
  
} else if (calificacion_final<6.0){
  
  print("Feliz navidad, nos volveremos a ver")
}

  
  
  
  
  
