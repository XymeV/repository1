                                    ### Principio del tio Ben ###

#Para realizar los codigos se consultaron distintas paginas webs y foros. No se usaron recursos de inteligencia artificial en estos codigos

poder_personajes<-c(10000,5000,600,1000,12000,5000,3000,8000,15000,60) #Creamos un vector con los niveles de poder

personajes<-c("Spiderman2099","ChocoTavo","Kuri","ironman","DarthVader","Grogu","Pikachu","El PRI","AMLO","Abraham") # Creamos un vector con los nombres de los personajes

names(poder_personajes)<-personajes #Asignamos un nivel de poder a cada personaje

poder_personajes

posicion<- as.numeric (readline (prompt = "Elige el número de tu personaje, debe estar en el intervalo 1-10: ")) #El usuario elige su personaje en función de la posicion del mismo en el vector.

personaje<- poder_personajes[[posicion]] #asignamos el personaje elegido por el usuario al objeto "personaje"

# Veamos que tan poderoso es tu personaje

if(personaje==10000){ #Use el "if" para establecer la condicion 
  
  print("Un GRAN PODER conlleva una GRAN RESPONSABILIDAD")#Imprimimos LA frase
  
  print(paste("Tu personaje es: ",personajes[[posicion]])) #Imprimimos el nombre del personaje elegido por el usuario en funcion de su posicion en el vector "personajes", posicion que fue elegida por el usuario
  
  print(paste("El poder de tu personaje es: ",poder_personajes[[posicion]]))#Imprimimos el poder del personaje elegido por el usuario en funcion de su posicion en el vector "poder_personajes"
  
} else if (personaje<10000){
  
  print("Eres un guerrero de clase baja")
  
  print(paste("Tu personaje es: ",personajes[[posicion]])) 
  
  print(paste("El poder de tu personaje es: ",poder_personajes[[posicion]]))
  
} else if (personaje>=10000){
  
  print("Un GRAN PODER conlleva una GRAN RESPONSABILIDAD")#Imprimimos LA frase
  
  print("¡SU PODER ES DE MAS DE 10,000!")
  
  print(paste("Tu personaje es: ",personajes[[posicion]])) #Imprimimos el nombre del personaje elegido por el usuario en funcion de su posicion en el vector "personajes", posicion que fue elegida por el usuario
  
  print(paste("El poder de tu personaje es: ",poder_personajes[[posicion]]))
  
}




