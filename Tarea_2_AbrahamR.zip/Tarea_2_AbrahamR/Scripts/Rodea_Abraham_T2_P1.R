                                  ### Ecuación cuadratica ### 

#Para realizar los codigos se consultaron distintas paginas webs y foros. No se usaron recursos de inteligencia artificial en estos codigos

# Elabora un programa en R, profusamente comentado, que dados los valores de los coeficientes de una ecuaci´on cuadr´atica, es decir los valores de a, b, c de la ecuaci´on ax2 + bx + c = 0b arroje lo siguiente:

#(a) Las dos soluciones cuando estas son reales.

#(b) Cuando se tenga solo una solucion lo indique y mande un mensaje diciendo porque solo se tiene una soluci´on.

#(c) Cuando no se tienen soluciones reales que mande un mensaje que indique que no existen soluciones en los n´umeros reales y explique porqu´ e.


### El siguiente código te permitirá descubrir el o los valores de X en una ecuación cuadratica ###

#Para ejecutar el siguiente codigo no es necesario cargar ningun paquete extra 

## Coloca los valores de tu ecuacion, recuerda que deben ser valores de tipo numerico ### 

a <- as.numeric (readline (prompt = "valor a de tu ecuacion: ")) # Use un "readline" para permitir que el usuario coloque los valores especificos de su ecuación

b <- as.numeric (readline (prompt = "valor b de tu ecuacion: ")) # Use "as.numeric" para guardar el valor introducido por el usuario como numerico, de lo contrario el objeto se guardaria como caracter

c <- as.numeric (readline (prompt = "valor c de tu ecuacion: ")) # Para que el codigo funcione es necesario introducir valores numericos 

### Este codigo calcula el valor de x usando la formula general para ecuaciones cuadraticas ### 

# primero calculamos el valor de la discriminante #

# Recordemos que la discriminante se calcula de la siguiente forma:[-b (+/-) √ b^2 - 4ab] / 2a = discriminante #

discriminante<-b^2 - 4 * a * c # colocamos las operaciones necesarias para calcular la discriminate y las asigne al objeto "discriminante" 

print(paste("Valor de la discriminante: ", discriminante)) # Se muestra el valor de la discriminante. Use "print" para imprimir la leyenda "Valor de la discriminante: ", use "paste" para imprimir el valor numerico del objeto "discriminante"

### Para calcular los valores de X1 y X2 usaremos el valor de la discriminante ###

if (discriminante>0){ # (a) Use "if" debido a que es necesario que se cumpla la condición "discriminate>0" para obtener el resultado 

X1 <- (-b + sqrt(discriminante)) / (2 * a) # Calculamos el resultado de la formula general, use "sqrt" para obtener la raiz cuadrada de la discriminate, el valor de dicho objeto se obtuvo previamente

X2 <- (-b - sqrt(discriminante)) / (2 * a) # Se generan dos objetos X, uno para cada uno de los valores que dicha incognita puede tomar en la ecuacion. La diferencia entre ambos objetos radica unicamente en un simbolo, + para X1 y - para X2

print("Los valores de X son: ") # Use "print" para colocar una leyenda que indique que se estan proporcionando los valores de X

print(paste("Valor de X1: ", X1)) # Primer valor de X, imprimimos una leyenda que indica que se presenta cada uno de los valores de las incognitas 

print(paste("Valor de X2: ", X2))# Segundo valor de X, use "paste" para agregar el valor de la incognita 

} else if (discriminante == 0){ # (b) Use "else if" en caso de que no se cumpla la primer condición, en caso de que se cumpla la condicion de esta línea se ejecutará lo siguiente 

X<- -b / (2 * a) # Cuando solo existe una solución, pues, el valor de la discriminate es 0, en este caso realizamos la operación: -b/2a

print("Solo existe una solución") # Usando "print" se imprime la leyenda que aclara al usuario que su ecuación solo posee un resultado

print("Solo exite una solución debido a que el valor de la discriminante es 0, por lo tanto, el unico valor de X se calcula con la siguiente operacion: -b / (2 * a) ")

print(paste("Valor de X: ", X)) # Imprimimos el resultado unico

} else if (discriminante<0){ # (c) Nuevamente use "if.else" en caso de que se cumpla el escenario descrito en esta linea, se ejecutara lo siguiente 
 
print("El resultado no esta dentro de los numeros reales") # En las siguientes lineas aclaramos al usuario el porque su ecuación no tiene un resultado en los reales
  
print("La discriminante de tu ecuacion tiene un valor negativo, por lo tanto, su raiz cuadrada siempre será un numero imaginario")
  
print("El resultado de la raiz de tu discriminate es imaginario debido a que no existe un numero real que al elevarlo al cuadrado arroje un numero negativo")
  }
  
  


