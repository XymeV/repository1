                                     ### Indice de masa corporal ###

#Para realizar los codigos se consultaron distintas paginas webs y foros. No se usaron recursos de inteligencia artificial en estos codigos

### Solicitamos datos al usuario ###

nombre<- as.character (readline (prompt = "Tu nombre es: ")) #Use "as.character" debido a que este dato no posee valor numerico

estatura<- as.numeric (readline (prompt = "Tu estatura en metros es: "))

peso<- as.numeric (readline (prompt = "Tu peso en kilos es: "))

tu_IMC<- peso / estatura^2 # Calculamos el IMC del usuario

tu_IMC

if(tu_IMC<18.5){
  
  print(paste("Tu peso es bajo", nombre))
  
  print(paste("Tu IMC es de: ", tu_IMC))
  
}else if(tu_IMC>=18.5 & tu_IMC<=24.9){
  
  print(paste("Tu peso es normal", nombre))
  
  print(paste("Tu IMC es de: ", tu_IMC))
  
}else if(tu_IMC>24.9 & tu_IMC<=29.9){
  
  print(paste("Tienes sobrepeso", nombre))
  
  print(paste("Tu IMC es de: ", tu_IMC))

}else if(tu_IMC > 29.9){
  
  print(paste("Tienes obesidad", nombre))
  
  print(paste("Tu IMC es de: ", tu_IMC))
  
}




