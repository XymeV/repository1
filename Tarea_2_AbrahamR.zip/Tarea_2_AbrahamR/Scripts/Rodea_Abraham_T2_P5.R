                   ###  Elabora un programa en R que a partir de un archivo FASTA concatenado de secuencias que se anexa a esta actividad haga lo siguiente:

#Para realizar los codigos se consultaron distintas paginas webs y foros. No se usaron recursos de inteligencia artificial en estos codigos

#(a) El numero de veces que aparece la secuencia GATTACA

#(b) La secuencia traducida

#(c) El alineamiento multiple por al menos dos algoritmos distintos para la secuencia de AA

#(d) Una matriz de distancias de las secuencias

#(e) Un arbol filogenetico a partir de uno de los alineamientos

### Para correr el siguiente codigo necesitas las siguientes librerias ###

install.packages("stringdist")

library(Biostrings)

library(BiocGenerics)

library(msa)

library(stats)

library(ape)

library(stringdist)

### Abrimos la secuencia con la que vamos a trabajar ###

secuencia<- readDNAStringSet("Bases_de_datos/FASTA.fa") # Usamos la funcion "readDNAStringSet" de la libreria "Biostrings" para leer las secuencias del archivo .fa. La direccion de la secuencia es "Bases_de_datos/FASTA.fa", esto permite que cualquiera con este proyecto pueda abrir dicha base de datos  
secuencia

tamaño_de_secuencias<-width(secuencia) #Usamos la funcion "width para conocer el tamaño de cada una de las secuencias del set

tamaño_de_secuencias

### (a) El numero de veces que aparece la secuencia GATTACA

numero_de_GATTACA<- vcountPattern("GATTACA",secuencia) # Use la funcion "vcountPatter" para contar la cantidad de veces que aparece el patron "GATTACA" en cada una de las secuencias del set

numero_de_GATTACA # Muestra el número de veces que aparece el patron "GATTACA en cada una de las secuencias. Cunado se trabaja con sets se debe usar "vcountPatter" en lugar de "countPatter"

### (b) La secuencia traducida ### 

secuencias_traducidas<-translate(secuencia) #No podemos traducirlas debido a que la secuencia 3 tiene una letra R en lugar de una base nitrogenada en la posicion 28

secuencia_traducida1<-translate(secuencia, genetic.code=GENETIC_CODE, if.fuzzy.codon="solve") #Usando la siguiente funcion podemos traducir secuencias con letras IUPAC.En el apartado de "code" coloque "GENETIC_CODE" para especificar a la maquina que estamos trabajando con el alfabeto IUPAC. En el apartado de "codon" coloque "solve", esto permite traducir los codones cuya traduccion no sea ambigua, pueden ser traducidos a un aminoacido o a un codon de paro. Los codones de traducción difusa apareceran como "X"        

secuencia_traducida1 # Imprimir las secuencias traducidas

### (c) El alineamiento multiple por lo menos con dos algoritmos distintos para la secuencia de AA

alineamiento_clustalW<-msa(secuencia_traducida1,method = "ClustalW") # Usamos la funcion "msa" de la libreria "msa" para realizar el alineamineto. En este caso se usa el metodo de "ClustalW". Estamos usando "secuencia_traducida1" debido a que el ejercicio pide que el alinemamiento sea de las secuencias de aminoacidos

alineamiento_clustalW # Imprimir el alineaminto

alineamiento_Muscle<-msa(secuencia_traducida1,method = "Muscle") # En este caso usamos el metodo "Muscle"

alineamiento_Muscle # Imprimir el alineamiento

###(d) Una matriz de distancias de las secuencias ###

matriz_de_secuencias<- as.DNAbin(secuencia) #Convertimos el objeto "secuencia" al tipo "DNAbin", pues, es el formato requerido por la función "dist.dna", esta funcion es de la libreria "ape"
matriz_de_secuencias

nombres_de_secuencia<-c("secuencia 1","secuencia 2", "secuencia 3","secuencia 4","secuencia 5", "secuencia 6","secuencia 7","secuencia 8","secuencia 9","secuencia 10","secuencia 11","secuencia 12") #Escribi un vector de nombres para asignarle a cada secuencia

names(matriz_de_secuencias)<-nombres_de_secuencia # Asignamos los nombres a las secuencias
matriz_de_secuencias

matriz_de_distancias<- dist.dna(matriz_de_secuencias,model = "raw", variance = FALSE, # Usamos la funcion "dist.dna" para calcular la matriz de distancias
                                gamma = FALSE, pairwise.deletion = TRUE,
                                base.freq = NULL, as.matrix = FALSE)
matriz_de_distancias

#### En este caso no me fue posible conseguir la matriz de distancias, probe con muchos metodos pero en todos ellos tenia problemas por los tamaños dispares de las secuencias 
### Leyendo el apartado de help de la funcion "dist.dna" me encontre con la siguiente leyenda: "If the sequences are very different, most evolutionary distances are undefined and a non-finite value (Inf or NaN) is returned"
### Cuando ejecuto el codigo aparece una matriz de distancias, sin embargo, esta completamente llena de "NaN", lo cual coincide con lo mencionado en la pestaña de help
### Este resultado me hace un poco de sentido considerando que se tiene una secuencia de 480 nucleotidos y otra de 30,123 nucleotidos

#(e) Un arbol filogenetico a partir de uno de los alineamientos

### Debido a que no fui capaz de generar una matriz de distancias tampoco me fue posible generar un arbol filogenetico, pues, todos ellos requieren una matriz de distancias


