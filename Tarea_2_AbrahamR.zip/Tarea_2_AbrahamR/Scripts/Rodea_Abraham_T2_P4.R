### Estructuras de seleccion ### 

# Elabora un programa que a partir de la fecha de nacimiento de cualquier persona, dando como datos de entrada d´ ıa, mes y a˜no en formato num´erico calcule lo siguiente:

#(a)Su edad en years

#(b)Su signo zodiacal

#(c)La estacion del year en el que nacio

### Tus datos ###

dia<- as.numeric (readline (prompt = "En que dia naciste, responde en número: ")) # Use un "readline" para permitir que el usuario coloque sus datos

mes <- as.numeric (readline (prompt = "En que mes naciste, responde en número: ")) # Use "as.numeric" para guardar el valor introducido por el usuario como numerico, de lo contrario el objeto se guardaria como caracter

year<- as.numeric (readline (prompt = "En que year naciste, responde en número: "))


## (a) Edad en years ## 

tu_edad<-2024 - year # Un fallo en este codigo es que en años posteriores a 2024 el resultado sería incorrecto

tu_edad<-print(paste("Tienes: ",tu_edad,"years")) #Imprimimos la edad en años del usuario 

## (b) Tu signo zodiacal ##

if ( (mes == 3 & dia>=21) | (mes == 4 & dia <=19)) { # Definimos el intervalo de tiempo para cada uno de los 12 signos
  print ("Eres aries")
} else if ((mes == 4 & dia>=20) | (mes == 5 & dia <=20)) { # Usamos el operador "|" debido a que cualquier número que se encuentre dentro de cualquiera de las dos condiciones cumple las condiciones para tener dicho signo
  print ("Eres tauro")
} else if ( (mes == 5 & dia>=21) | (mes == 6 & dia <=20)) { # Usamos "else if" para abarcar todos los posibles intervalos
  print ("Eres géminis")
} else if ( (mes == 6 & dia>=21) | (mes == 7 & dia <=22)) {
  print ("Eres cáncer")
} else if ( (mes == 7 & dia>=27) | (mes == 8 & dia <=22)) {
  print ("Eres leo")
} else if ( (mes == 8 & dia>=23) | (mes == 9 & dia <=22)) {
  print ("Eres virgo")
} else if ( (mes == 9 & dia>=23) | (mes == 10 & dia <=22)) {
  print ("eres libra")
} else if ( (mes == 10 & dia>=23) | (mes == 11 & dia <=21)) {
  print ("Eres escorpio")
} else if ( (mes == 11 & dia>=22) | (mes == 12 & dia <=21)) {
  print ("Eres sagitario")
  print("El mejor caballero del zodiaco")
} else if ( (mes == 12 & dia>=22) | (mes == 1 & dia <=19)) {
  print ("Eres capricornio")
} else if ( (mes == 1 & dia>=20) | (mes == 2 & dia <=18)) {
  print ("Eres acuario")
} else if ( (mes == 2 & dia<=19) | (mes == 3 & dia >=20)) {
  print ("Eres piscis")
} 

### (c) En que estacion naciste ### 

if( mes == 12 & dia>=21|mes == 1 & dia >=1 |mes == 2 & dia >= 1|mes == 3 & dia<20) { # Use el operador "|" debido a que si el mes y dia de nacimiento del usuario se encuentra dentro de cualquiera de estos intervalos pertenece a dicha estacion
  print ("Naciste en invierno")
} else if ( mes == 3& dia >= 20|mes == 4& dia >= 20|mes==5& dia >= 1|mes == 6 & dia <20){ # Las estaciones fueron delimitadas en funcion de los solsticios y equinoccios 
  print ("Naciste en primavera")
} else if ( mes == 6 & dia >= 20|mes==7 & dia >=1|mes== 8 & dia >=1|mes== 9 & dia <22){
  print ("Naciste en verano")
} else if (mes == 9 & dia >= 22|mes == 10 & dia >= 1|mes == 11 & dia >=1|mes == 12 & dia <21){
  print ("Naciste en otoño")
}


